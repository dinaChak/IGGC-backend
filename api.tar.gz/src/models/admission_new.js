const mongoose = require('mongoose');

const AdmissionNewSchema = new mongoose.Schema({
  semester: {
    instruction: String,
    feeStructure: String,
  },
  hostel: String,
});

const AdmissionNew = mongoose.model('AdmissionNew', AdmissionNewSchema);

module.exports = { AdmissionNew };
