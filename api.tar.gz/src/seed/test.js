const { branchSubjects } = require('./subjects');

console.log(branchSubjects['b.a'][0]);
