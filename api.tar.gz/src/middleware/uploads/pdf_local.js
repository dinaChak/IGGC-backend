const multer = require('multer');
const path = require('path');

const myCustomStorage = require('../../utilities/file_custom_storage');

class PDFMulter {
  constructor(fieldName, basePath, baseDir) {
    this.storage = myCustomStorage({
      basePath,
      baseDir,
    });
    this.fieldName = fieldName;
    this.upload = multer({
      storage: this.storage,
      fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        if (ext !== '.pdf') {
          const err = new Error('Only PDF is allowed');
          err.message = 'Only PDF is allowed';
          return cb(err);
        }
        return cb(null, true);
      },
    }).single(fieldName);
  }

  fieldValidationRequired(req, res, next) {
    this.upload(req, res, (err) => {
      const fileErrors = [];
      if (!req.file) {
        fileErrors.push({
          location: 'body',
          msg: 'please provide a PDF file',
          param: this.fieldName,
        });
      }
      if (err) {
        fileErrors.push({
          location: 'body',
          msg: err.message,
          param: this.fieldName,
        });
      }
      if (fileErrors.length > 0) res.locals.fileErrors = fileErrors;
      next();
    });
  }

  fieldValidationOptional(req, res, next) {
    this.upload(req, res, (err) => {
      const fileErrors = [];
      if (err) {
        fileErrors.push({
          location: 'body',
          msg: err.message,
          param: this.fieldName,
        });
      }
      if (fileErrors.length > 0) res.locals.fileErrors = fileErrors;
      next();
    });
  }
}

module.exports = ({
  basePath,
  baseDir,
  fieldName = 'file',
}) => new PDFMulter(
  fieldName,
  basePath,
  baseDir,
);
