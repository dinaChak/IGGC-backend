const { body } = require('express-validator/check');
const { sanitizeBody } = require('express-validator/filter');
const { validationResult } = require('express-validator/check');

const admissionNewValidation = [
  body('instruction')
    .optional({ nullable: true, checkFalsy: true }),
  body('feeStructure')
    .optional({ nullable: true, checkFalsy: true }),

  sanitizeBody('instruction')
    .trim(),
  sanitizeBody('feeStructure')
    .trim(),

  (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).send({
        errors: errors.array(),
      });
    }
    return next();
  },
];

module.exports = { admissionNewValidation };
